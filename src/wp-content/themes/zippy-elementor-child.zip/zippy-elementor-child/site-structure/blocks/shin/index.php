
<h1 class="shin"><?php if ( get_field('title') ) : ?>
    <span> <?php the_field('title') ?></span>
<?php endif; ?>
</h1>